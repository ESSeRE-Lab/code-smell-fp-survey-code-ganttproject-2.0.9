/*
 * Created on 22.09.2005
 */
package org.ganttproject.impex.htmlpdf;

import java.net.URL;

public interface Stylesheet {

    String getLocalizedName();
    URL getUrl();
}
