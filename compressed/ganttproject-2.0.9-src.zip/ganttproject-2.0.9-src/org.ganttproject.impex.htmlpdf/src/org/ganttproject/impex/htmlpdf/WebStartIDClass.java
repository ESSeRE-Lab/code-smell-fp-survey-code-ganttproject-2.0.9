package org.ganttproject.impex.htmlpdf;

public class WebStartIDClass {

}
