/*
 * Created on 26.09.2005
 */
package org.ganttproject.impex.htmlpdf;

public interface PDFStylesheet extends Stylesheet {

}
