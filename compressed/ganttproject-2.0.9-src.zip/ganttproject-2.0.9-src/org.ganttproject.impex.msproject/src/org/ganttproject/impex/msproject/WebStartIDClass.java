package org.ganttproject.impex.msproject;

public class WebStartIDClass {

}
