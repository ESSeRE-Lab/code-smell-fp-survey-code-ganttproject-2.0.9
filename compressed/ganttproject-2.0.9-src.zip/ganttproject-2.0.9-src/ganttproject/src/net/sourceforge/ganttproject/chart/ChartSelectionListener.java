package net.sourceforge.ganttproject.chart;

public interface ChartSelectionListener {
	public void selectionChanged();
}
