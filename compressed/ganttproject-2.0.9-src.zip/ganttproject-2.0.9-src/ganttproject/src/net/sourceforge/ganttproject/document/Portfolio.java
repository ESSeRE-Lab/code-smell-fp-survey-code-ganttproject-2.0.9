package net.sourceforge.ganttproject.document;

public interface Portfolio {
    Document getDefaultDocument();
}
