package net.sourceforge.ganttproject;

public interface GPVersion {
    String V2_0_1 = "2.0.1";
    String V2_0_2 = "2.0.2";
    String V2_0_3 = "2.0.3";
    String V2_0_4 = "2.0.4";
    String V2_0_5 = "2.0.5";
    String V2_0_6 = "2.0.6";
    String V2_0_7 = "2.0.7";
    String V2_0_8 = "2.0.8";
    String V2_0_9 = "2.0.9";
	String V2_0_X = V2_0_9;
}
