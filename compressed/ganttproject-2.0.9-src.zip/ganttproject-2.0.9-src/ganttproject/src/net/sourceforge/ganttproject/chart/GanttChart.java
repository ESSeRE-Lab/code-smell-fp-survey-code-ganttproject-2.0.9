package net.sourceforge.ganttproject.chart;

public interface GanttChart extends Chart {

    void appendBlankRow();

}
