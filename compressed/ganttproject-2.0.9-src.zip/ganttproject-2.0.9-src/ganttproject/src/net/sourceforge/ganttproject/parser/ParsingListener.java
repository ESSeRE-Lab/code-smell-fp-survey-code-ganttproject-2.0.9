package net.sourceforge.ganttproject.parser;

public interface ParsingListener {
    public void parsingStarted();

    public void parsingFinished();
}
