package net.sourceforge.ganttproject.task;

public interface CustomColumsListener {
    public void customColumsChange(CustomColumEvent event);
}
