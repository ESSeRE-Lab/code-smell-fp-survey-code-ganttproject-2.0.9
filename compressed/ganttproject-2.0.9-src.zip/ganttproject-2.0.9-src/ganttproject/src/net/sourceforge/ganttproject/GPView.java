/*
 * Created on 26.05.2005
 */
package net.sourceforge.ganttproject;

/**
 * @author bard
 */
public interface GPView {
    void setVisible(boolean isVisible);

    boolean isVisible();
}
