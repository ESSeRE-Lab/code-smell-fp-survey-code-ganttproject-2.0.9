package net.sourceforge.ganttproject.parser;

import org.xml.sax.Attributes;

public class DayTypeTagHandler implements TagHandler {

    public void startElement(String namespaceURI, String sName, String qName,
            Attributes attrs) throws FileFormatException {
        // TODO Auto-generated method stub

    }

    public void endElement(String namespaceURI, String sName, String qName) {
        // TODO Auto-generated method stub

    }

}
