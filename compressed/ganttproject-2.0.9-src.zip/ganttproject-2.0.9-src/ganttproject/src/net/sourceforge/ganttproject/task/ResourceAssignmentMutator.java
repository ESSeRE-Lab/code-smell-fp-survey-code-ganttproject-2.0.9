package net.sourceforge.ganttproject.task;

public interface ResourceAssignmentMutator extends
        MutableResourceAssignmentCollection {
    void commit();
}
