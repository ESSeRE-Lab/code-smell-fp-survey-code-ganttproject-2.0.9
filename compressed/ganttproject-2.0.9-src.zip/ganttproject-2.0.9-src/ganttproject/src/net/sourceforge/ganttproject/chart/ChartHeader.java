/*
 * Created on 17.06.2004
 *
 */
package net.sourceforge.ganttproject.chart;

/**
 * @author bard
 */
public interface ChartHeader {
}
