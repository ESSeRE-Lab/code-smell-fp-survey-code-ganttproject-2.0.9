package net.sourceforge.ganttproject.resource;

import net.sourceforge.ganttproject.task.ResourceAssignment;

public interface AssignmentContext {
    public ResourceAssignment[] getResourceAssignments();
}
