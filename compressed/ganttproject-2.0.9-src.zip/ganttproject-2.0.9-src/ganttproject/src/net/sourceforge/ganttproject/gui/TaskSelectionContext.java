package net.sourceforge.ganttproject.gui;

import java.util.List;

import net.sourceforge.ganttproject.task.Task;

public interface TaskSelectionContext {

	List getSelectedTasks();

}
