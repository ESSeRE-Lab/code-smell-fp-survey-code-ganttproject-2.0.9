package net.sourceforge.ganttproject.task;

public interface TaskInfo {

}
