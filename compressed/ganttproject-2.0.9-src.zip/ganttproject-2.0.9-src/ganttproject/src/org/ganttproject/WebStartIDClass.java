package org.ganttproject;

public class WebStartIDClass {

}
