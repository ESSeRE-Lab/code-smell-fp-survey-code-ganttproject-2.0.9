package org.ganttproject.chart.pert;

public class WebStartIDClass {

}
